# Contributing Guide

Please follow the contribution guidelines provided within the keptn/keptn repo: 

* https://github.com/keptn/keptn/blob/master/CODE_OF_CONDUCT.md
* https://github.com/keptn/keptn/blob/master/CONTRIBUTING.md
